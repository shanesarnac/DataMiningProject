# DataMiningProject
Attempting to predict the performance of baseball players and determine their value. 
