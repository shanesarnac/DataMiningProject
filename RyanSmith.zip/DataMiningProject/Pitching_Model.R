# Regression Analysis - Ryan Smith
#
# Regression code at bottom




# Copied from Shane
#############################
# Find the age that a player was for the year in question. The adopted convention for this
# project is that if a player's birthday occured before July, the player's season age is his
# birth age. If a player's birthday occured in July or after, the player's season age is one
# year younger than his birth age. 
findSeasonAge = function(season_year, birth_year, birth_month) {
  effective_birth_year = ifelse(birth_month < 7, birth_year, birth_year - 1) 
  age = season_year - effective_birth_year
  return (age)
}

# Uses the Teams class to determine how many strikeouts were thrown each year from a start year
# through 2015
findTotalStrikeouts = function(start_year) {
  total = sum(teams$SOA[which(teams$yearID == start_year)])
  for (i in (start_year+1):2015) {
    total = c(total,sum(teams$SOA[which(teams$yearID == i)]))
  }
  #print(total)
  return (total)
}
avgStrikoutGivenYear = function(start_year) {
  
  pitcherSO = pitchers$SO[which(pitchers$yearID == start_year & pitchers$IP >= 90 & pitchers$GS >= 7 )]
  topPitchingMean = quantile(pitcherSO, c(.9)) 
  
  return(mean(pitchers$SO[which(pitchers$SO > topPitchingMean & pitchers$yearID == start_year & pitchers$IP >= 90 & pitchers$GS >= 7)]))
  #return(mean(pitchers$SO[which(pitchers$yearID == start_year & pitchers$IP >= 90 & pitchers$GS >= 15)]))
}
winsGivenYear = function(start_year) {
  wins = pitchers$W[which(pitchers$yearID == start_year & pitchers$IP >= 90 & pitchers$GS >= 7 )]
  topWinMean = quantile(wins, c(.90)) 
  
  return(mean(pitchers$W[which(pitchers$W >= topWinMean & pitchers$yearID == start_year & pitchers$IP >= 90 & pitchers$GS >= 7)]))
  #return(mean(pitchers$W[which(pitchers$yearID == start_year & pitchers$IP >= 90 & pitchers$GS >= 15)]))
}
eraGivenYear = function(start_year) {
  era = pitchers$ERA[which(pitchers$yearID == start_year & pitchers$IP >= 100 & pitchers$GS >= 7)]
  topERAMean = quantile(era, c(.05)) 
  pitcherSO = pitchers$SO[which(pitchers$yearID == start_year & pitchers$IP >= 90 & pitchers$GS >= 7 )]
  topPitchingMean = quantile(pitcherSO, c(.95)) 
  
  return(mean(pitchers$ERA[which(pitchers$SO <= topPitchingMean & pitchers$yearID == start_year & pitchers$IP >= 100 & pitchers$GS >= 7)]))
  #return(mean(pitchers$W[which(pitchers$yearID == start_year & pitchers$IP >= 90 & pitchers$GS >= 7)]))
}


# Uses the Teams class to determine the total number of earned runs given up each year, starting
# at a given base year and ending at a given end year. 
findTotalOpponentEarnedRuns = function(start_year, end_year) {
  total = sum(teams$RA[which(teams$yearID == start_year)])
  for (i in (start_year+1):end_year) {
    total = c(total,sum(teams$RA[which(teams$yearID == i)]))
  }
  #print(total)
  return (total)
}


# Determines the total number of strikeouts that players of a given age produced per year, 
# starting and ending at given years
findTotalStrikeoutsAge = function(start_year, end_year, effective_age) {
  total = sum(pitchers$SO[which(pitchers$effective_age[which(pitchers$yearID == start_year)
                                                       ] == effective_age)])
  for(i in (start_year+1):end_year) {
    total = c(total, sum(pitchers$SO[which(pitchers$effective_age[
      which(pitchers$yearID == i)] == effective_age)]))
  }
  return (total)
}


# Determines the average number of strikeouts thrown by pitchers of a given age each year, 
# given a range of years.
findAverageStrikeoutsAge = function(start_year, end_year, effective_age) {
  total = mean(pitchers$SO[which(pitchers$effective_age[which(pitchers$yearID == start_year)
                                                       ] == effective_age)])
  for(i in (start_year+1):end_year) {
    total = c(total, mean(pitchers$SO[which(pitchers$effective_age[
      which(pitchers$yearID == i)] == effective_age)]))
  }
  return (total)
}

# Determines the average number of strikeouts thrown by pitchers of a given age each year, 
# given a range of years and a minimum threshold for number of innings thrown. 
findAverageStrikeoutsAge = function(start_year, end_year, effective_age, min_innings) {
  pitchers_in_year = which(pitchers$yearID == start_year)
  pitchers_at_age = which(pitchers$effective_age[pitchers_in_year] == effective_age)
  pitchers_with_min_innings = which(pitchers$IP[pitchers_at_age] >= min_innings)
  total = mean(pitchers$SO[pitchers_with_min_innings])
  for(i in (start_year+1):end_year) {
    pitchers_in_year = which(pitchers$yearID == i)
    pitchers_at_age = which(pitchers$effective_age[pitchers_in_year] == effective_age)
    pitchers_with_min_innings = which(pitchers$IP[pitchers_at_age] >= min_innings)
    total = c(total, mean(pitchers$SO[pitchers_with_min_innings]))
  }
  return (total)
}

# Read in data from the Pitching, Team, and  Master csv files from Lahmann database
pitchers = read.csv(file = 'Baseball/Pitching.csv', header = TRUE)
batters = read.csv(file = 'Baseball/Batting.csv', header = TRUE)
teams = read.csv(file = 'Baseball/Teams.csv', header = TRUE)
master = read.csv(file = 'Baseball/Master.csv', header = TRUE)

# Find where all pitchers are listed in the Master csv file
pitcher_indices_in_master = match(pitchers$playerID, master$playerID)

# Determine the age of the pitcher during a given season
pitchers$effective_age = findSeasonAge(
  pitchers$yearID,
  master$birthYear[pitcher_indices_in_master],
  master$birthMonth[pitcher_indices_in_master]
)

# Convert IPouts to IP (innings pitched)
pitchers$IP = pitchers$IPouts/3

# Determine the trends in strikeouts since 1999
years_since_1998 = which(teams$yearID > 1998)

par(mfrow = c(1,2))
plot(x = 1900:2014, y = findTotalStrikeouts(1900), main = "Total Strikeouts in MLB per Year",
     xlab = "Year", ylab = "Total Number of Strikeouts by Pitchers")
plot(x = 1900:2014, y = findTotalOpponentEarnedRuns(1900, 2014), main = "Total Runs Allowed in MLB per Year", 
     xlab = "Year", ylab = "Total Runs Scored")

# Determine trends in strikeouts by age per year
par(mfrow = c(1,1))
plot(x = 1999:2014, y = findAverageStrikeoutsAge(1999, 2014, 20, 150), col = "blue")
plot(x = 1999:2014, y = findAverageStrikeoutsAge(1999, 2014, 21, 150), col = "red")
plot(x = 1999:2014, y = findAverageStrikeoutsAge(1999, 2014, 22, 150), col = "green")
plot(x = 1999:2014, y = findAverageStrikeoutsAge(1999, 2014, 23, 150), col = "orange")
plot(x = 1999:2014, y = findAverageStrikeoutsAge(1999, 2014, 24, 150), col = "purple")
plot(x = 1999:2014, y = findAverageStrikeoutsAge(1999, 2014, 25, 150), col = "yellow")
plot(x = 1999:2014, y = findAverageStrikeoutsAge(1999, 2014, 26, 150), col = "coral")
plot(x = 1950:2014, y = findAverageStrikeoutsAge(1950, 2014, 27, 150))
################

/* Checking interesting relationships and learning r
 */

// starting with ERA vs time ///////////////////////
avg_SO_1999 = avgStrikoutGivenYear(1999)
for( i in 2000:2015) {
  avg_SO_1999 = c(avg_SO_1999, avgStrikoutGivenYear(i))
}
plot(x = 1999:2015, y = avg_SO_1999, main = 'Average Strike-Outs for 90th percentile', ylab = 'Strike Outs', xlab = 'Year')

avg_W_1999 = winsGivenYear(1999)
for( i in 2000:2015) {
  avg_W_1999 = c(avg_W_1999, winsGivenYear(i))
}
plot(x = 1999:2015, y = avg_W_1999, main = 'Average Wins for 90th percentile', ylab = 'Wins', xlab = 'Year')

avg_e_1999 = eraGivenYear(1999)
for( i in 2000:2015) {
  avg_e_1999 = c(avg_e_1999, eraGivenYear(i))
}
plot(x = 1999:2015, y = avg_e_1999, main = 'top era vs time', ylab = 'era', xlab = 'year')
plot(x = avg_SO_1999, y = avg_e_1999, main = 'relationship', ylab = 'era', xlab = 'W')
////////////////////////////


findAverageStrikeoutsAge(2000, 2014, 26,150)


/// Building data for Regression anaysis


battersName = batters2$playerID[which(batters$yearID >= 1999 & batters$AB >= 100)]
battersLastName = master$nameLast
battersRBI = batters$RBI[which(batters$yearID >= 1999 & batters$AB >= 100)]
battersHR = batters$HR[which(batters$yearID >= 1999 & batters$AB >= 100)]
battersTeam = batters$teamID[which(batters$yearID >= 1999 & batters$AB >= 100)]
battersYear = batters$yearID[which(batters$yearID >= 1999 & batters$AB >= 100)]
battersBB = batters$BB[which(batters$yearID >= 1999 & batters$AB >= 100)]
battersSO = batters$SO[which(batters$yearID >= 1999 & batters$AB >= 100)]
batterDebut = substring(master$debut,0,4)
battersXP = (as.numeric(final$year) - as.numeric(final$Debut))
battersRookieRBI = batters$RBI[which(batters$yearID >= 1999 & batters$AB >= 100 & batters$playerID == "morneju01")]
battersRookieRBI = batters$RBI[which(batters$yearID == 2003 )]
battersG = batters$G[which(batters$yearID >= 1999 & batters$AB >= 100)]
battersAB = batters$AB[which(batters$yearID >= 1999 & batters$AB >= 100)]
battersOPS = batters$OPS[which(batters$yearID >= 1999 & batters$AB >= 100)]

battersName = final2Data$playerID[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersYear = final2Data$yearID.x[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersTeam = final2Data$teamID[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersAB = final2Data$AB[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersOPS = final2Data$OPS[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersFirstName = final2Data$First.Name[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersLastName = final2Data$Last.Name[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersXP = final2Data$XP[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersNationality = final2Data$Nationality[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersBats = final2Data$Bats[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersWeight = final2Data$Weight[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
battersHeight = final2Data$Height[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]
b = data.frame("playerID" = battersName, "year" = battersYear, "team" = battersTeam, "AB" = battersAB, "OPS" =  battersOPS, "First" = battersFirstName, "Last" = battersLastName, "XP" = battersXP, "Nationality" = battersNationality, "Bats" = battersBats, "Weight" = battersWeight, "Height" = battersHeight)
teamsyear = teams$yearID
teamsName = teams$teamID
teamsRank = teams$Rank
teamsW = teams$W
teamsPark = teams$park

masterName = master$playerID
masterBirthYear = master$birthYear

t = data.frame("yearID" , "teamID" = teamsName, "Rank" = teamsRank, "teamsW" = teamsW)


master$debut = substring(master$debut,0,4)
batters$yearID = as.numeric(batters$yearID)
bat2Stats = data.frame("playerID" = battersName, "yearID" = battersYear, "RBI" = battersRBI)
batStats = data.frame("playerID" = battersName, "Year" = battersYear, "Team" = battersTeam, "G" = battersG, "AB" = battersAB, "RBI"=battersRBI, "HR"=battersHR, "BB"=battersBB, "SO"=battersSO)
masStats = data.frame("playerID" = master$playerID, "First Name" = master$nameFirst, "Last Name" = master$nameLast, "XP" = (as.numeric(master$debut)), "Nationality" = master$birthCountry, "Bats" = master$bats, "Weight"= master$weight, "Height"= master$height, "yearID"= master$debut)
  
battersDATA = data.frame("playerID" = battersName, "Year" = battersYear, "Team" = battersTeam, "G" = battersG, "AB" = battersAB, "OPS" =  battersOPS, "RBI"=battersRBI, "HR"=battersHR, "BB"=battersBB, "SO"=battersSO)

batters2 = data.frame("playerID" = battersName, "year" = battersYear, "team" = battersTeam, "AB" = battersAB, "OPS" =  battersOPS)

plot(x = battersRBI, y = battersHR)
abline(lm(battersHR~battersRBI))
lm(battersRBI~battersHR+battersTeam+battersYear+battersBB+battersSO)

modelwww <- lm(www$OPS~www$age+www$year+www$team+www$XP+www$Bats+www$Weight+www$Height+ www$Nationality +www$twoAgoProduction + +www$lastYearProduction + www$rookieYearProduction + www$twoAgoOPS + www$lastYearOPS + www$rookieOPS + www$rookieAB + www$lastYearAB + www$twoAgoAB)
summary(modelwww)
merge <- merge(a, master, "playerID")
final <- merge(batStats, masStats, "playerID")
b <- read.table("batters")

final2Data$XP = (as.numeric(final2Data$yearID.x) - as.numeric(final2Data$yearID.y))
final2Data$yearID.x =  as.numeric(as.character(final2Data$yearID.x))
final2Data$yearID.y =  as.numeric(as.character(final2Data$yearID.y))
final2Data$XP = ((final2Data$year) - (final2Data$yearID))
final2 <- merge(final, batters, c("playerID", "yearID"))

final3Data = final2Data$.[which(final2Data$yearID.x >= 1999 & final2Data$AB >= 100)]

final2Data <- merge(batters3, masStats, "playerID")
batters2 = batters
batters3 = batters
batters4 = batters3

fone = f

names(batters4)[names(batters4)=="lastYearOPS"] <- "rookieOPS"
names(batters4)[names(batters4)=="lastYearAB"] <- "rookieAB"
names(b)[names(b)=="rookieYear"] <- "yearID"
f <- merge(batters4, b, c("yearID", "playerID"))

f$realRookieYear = ifelse(f$rookieAB < 75, 
                     f$rookieYear - 1, 
                     f$rookieYear)
fone$rookieAB <- NULL
fone$rookieOPS<- NULL
batters3$SB <- NULL 
batters3$R <- NULL
batters3$OBP <- NULL
batters3$CS<- NULL
batters3$SH <- NULL
batters3$G <- NULL
batters3$BB <- NULL
batters3$HR <- NULL 
batters3$IBB <- NULL
batters3$HBP <- NULL
batters3$SF <- NULL
batters3$GIDP <- NULL